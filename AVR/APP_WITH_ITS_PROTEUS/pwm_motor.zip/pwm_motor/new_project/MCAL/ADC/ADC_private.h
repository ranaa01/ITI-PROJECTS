/*
 * ADC_private.h
 *
 *  Created on: Apr 15, 2023
 *      Author: ranah
 */

#ifndef MCAL_ADC_ADC_PRIVATE_H_
#define MCAL_ADC_ADC_PRIVATE_H_



#endif /* MCAL_ADC_ADC_PRIVATE_H_ */

/*
 * ADC_interface.h
 *
 *  Created on: Apr 15, 2023
 *      Author: ranah
 */

#ifndef MCAL_ADC_ADC_INTERFACE_H_
#define MCAL_ADC_ADC_INTERFACE_H_

void adc_init();
u8 adc_readingchannel(u8 copy_channel);

#endif /* MCAL_ADC_ADC_INTERFACE_H_ */

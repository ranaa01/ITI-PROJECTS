/*
 * UART_conf.h
 *
 *  Created on: Apr 17, 2023
 *      Author: ranah
 */

#ifndef MCAL_UART_UART_CONF_H_
#define MCAL_UART_UART_CONF_H_

typedef struct{

};

#endif /* MCAL_UART_UART_CONF_H_ */

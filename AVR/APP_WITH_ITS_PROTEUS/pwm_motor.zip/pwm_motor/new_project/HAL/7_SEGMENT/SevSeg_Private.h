/*
 * SevSeg_Private.h
 *
 *  Created on: Mar 23, 2023
 *      Author: hisha
 */

#ifndef HAL_SEVSEG_SEVSEG_PRIVATE_H_
#define HAL_SEVSEG_SEVSEG_PRIVATE_H_

typedef enum
{
	WrongPort,
	WrongType
}SevErrState;
typedef enum
{
	Cathod,
	Anode

}SevSeg_Type;







#endif /* HAL_SEVSEG_SEVSEG_PRIVATE_H_ */

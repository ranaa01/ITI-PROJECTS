/*
 * INT_Confg.h
 *
 *  Created on: Apr 1, 2023
 *      Author: ranah
 */

#ifndef MCAL_INTERRUPT_INT_CONFG_H_
#define MCAL_INTERRUPT_INT_CONFG_H_



#endif /* MCAL_INTERRUPT_INT_CONFG_H_ */

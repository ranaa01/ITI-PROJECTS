/*
 * definition.h
 *
 *  Created on: Mar 22, 2023
 *      Author: hisha
 */

#ifndef COMMAN_DEFINITION_H_
#define COMMAN_DEFINITION_H_

#define Null  ((void *)0x00)

#endif /* COMMAN_DEFINITION_H_ */
